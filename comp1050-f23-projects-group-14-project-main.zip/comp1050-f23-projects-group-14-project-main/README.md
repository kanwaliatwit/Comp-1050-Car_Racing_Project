# javafx_maven_example
javafx_maven_example

Features:
* JavaFX
* Maven
* FXML
* Jar Export (May require additional DLLs and configuration)
