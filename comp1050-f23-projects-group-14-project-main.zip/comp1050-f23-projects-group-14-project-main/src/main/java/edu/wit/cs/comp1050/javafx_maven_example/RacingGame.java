//package application;
package edu.wit.cs.comp1050.javafx_maven_example;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.util.Timer;
import java.util.TimerTask;

public class RacingGame extends Application {

    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 600;

    private double playerX = WINDOW_WIDTH / 2;
    private double playerY = WINDOW_HEIGHT / 2;
    private double angle = 0;
    private double speed = 3.0;
    private double boostedSpeed = 5.0;
    private boolean isBoosted = false;
    private boolean canUseBoost = true;

    private Image carImage;

    private boolean crashed = false;

    private boolean upPressed = false;
    private boolean downPressed = false;
    private boolean leftPressed = false;
    private boolean rightPressed = false;

    private GraphicsContext gc;
    private Label boostStatusLabel = new Label();
    private Timer boostTimer;
    private Timer cooldownTimer;

    private Scene mainMenuScene;

    @Override
    public void start(Stage primaryStage) {
        StackPane mainMenu = new StackPane();
        mainMenu.setStyle("-fx-background-color: black;");
        mainMenu.setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        Label titleLabel = new Label("Race Yourself!");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 60));
        titleLabel.setTextFill(Color.WHITE);

        VBox vbox = new VBox(20);
        vbox.getChildren().addAll(titleLabel);

        Label playButton = new Label("PLAY");
        playButton.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        playButton.setTextFill(Color.WHITE);
        playButton.setOnMouseClicked(event -> startGame(primaryStage));

        Label exitButton = new Label("EXIT");
        exitButton.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        exitButton.setTextFill(Color.RED);
        exitButton.setOnMouseClicked(event -> Platform.exit());

        VBox menuComponents = new VBox(20);
        menuComponents.getChildren().addAll(playButton, exitButton);
        menuComponents.setAlignment(Pos.CENTER);

        vbox.getChildren().addAll(menuComponents);
        vbox.setAlignment(Pos.CENTER);
        
        mainMenu.getChildren().add(vbox);

        mainMenuScene = new Scene(mainMenu, WINDOW_WIDTH, WINDOW_HEIGHT);
        primaryStage.setScene(mainMenuScene);
        primaryStage.setTitle("RacingGame");
        primaryStage.show();

        carImage = new Image("Audi.png", 50, 50, true, true);
    }

    private void startGame(Stage primaryStage) {
        Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
        gc = canvas.getGraphicsContext2D();

        StackPane root = new StackPane(canvas, boostStatusLabel);
        Scene gameScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        gameScene.setFill(Color.BLUE); // Set the background color to grey

        primaryStage.setScene(gameScene);

        drawRaceTrack();
        addBackButton(primaryStage);

        new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
                render();
            }
        }.start();

        gameScene.setOnKeyPressed(e -> handleKeyPress(e.getCode()));
        gameScene.setOnKeyReleased(e -> handleKeyRelease(e.getCode()));
    }

    private void drawRaceTrack() {
        gc.clearRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        gc.setStroke(Color.BLACK);
        gc.setLineWidth(12);
        gc.strokeRect(50, 50, WINDOW_WIDTH - 100, WINDOW_HEIGHT - 100);

        gc.setStroke(Color.WHITE);
        gc.setLineWidth(6);
        gc.strokeLine(50, 50, WINDOW_WIDTH - 50, 50);
        gc.strokeLine(WINDOW_WIDTH - 50, 50, WINDOW_WIDTH - 50, WINDOW_HEIGHT - 50);
        gc.strokeLine(WINDOW_WIDTH - 50, WINDOW_HEIGHT - 50, 50, WINDOW_HEIGHT - 50);
        gc.strokeLine(50, WINDOW_HEIGHT - 50, 50, 50);

        gc.setStroke(Color.RED);
        gc.setLineWidth(4);
        gc.strokeLine(50, 50, WINDOW_WIDTH - 50, 50);
        gc.strokeLine(WINDOW_WIDTH - 50, 50, WINDOW_WIDTH - 50, WINDOW_HEIGHT - 50);
        gc.strokeLine(WINDOW_WIDTH - 50, WINDOW_HEIGHT - 50, 50, WINDOW_HEIGHT - 50);
        gc.strokeLine(50, WINDOW_HEIGHT - 50, 50, 50);
    }

    private void addBackButton(Stage primaryStage) {
        Label backButton = new Label("BACK");
        backButton.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        backButton.setTextFill(Color.GREY);
        backButton.setOnMouseClicked(event -> primaryStage.setScene(mainMenuScene));

        StackPane.setAlignment(backButton, javafx.geometry.Pos.TOP_LEFT);
        StackPane.setMargin(backButton, new javafx.geometry.Insets(10, 10, 0, 10));
        ((StackPane) primaryStage.getScene().getRoot()).getChildren().add(backButton);
    }

    private void handleKeyPress(KeyCode keyCode) {
        setDirection(keyCode, true);
        if (keyCode == KeyCode.SHIFT && canUseBoost) {
            isBoosted = true;
            canUseBoost = false;
            speed = boostedSpeed;
            startBoostTimer();
        }
    }

    private void handleKeyRelease(KeyCode keyCode) {
        setDirection(keyCode, false);
    }

    private void setDirection(KeyCode keyCode, boolean isPressed) {
        if (keyCode == KeyCode.UP || keyCode == KeyCode.W) {
            upPressed = isPressed;
        } else if (keyCode == KeyCode.DOWN || keyCode == KeyCode.S) {
            downPressed = isPressed;
        } else if (keyCode == KeyCode.LEFT || keyCode == KeyCode.A) {
            leftPressed = isPressed;
        } else if (keyCode == KeyCode.RIGHT || keyCode == KeyCode.D) {
            rightPressed = isPressed;
        }
    }

    private void update() {
        if (!crashed) {
            double deltaX = 0;
            double deltaY = 0;

            if (upPressed) {
                deltaX += (isBoosted ? boostedSpeed : speed) * Math.sin(Math.toRadians(angle));
                deltaY -= (isBoosted ? boostedSpeed : speed) * Math.cos(Math.toRadians(angle));
            }
            if (downPressed) {
                deltaX -= (isBoosted ? boostedSpeed : speed) * Math.sin(Math.toRadians(angle));
                deltaY += (isBoosted ? boostedSpeed : speed) * Math.cos(Math.toRadians(angle));
            }
            if (leftPressed) {
                angle -= 5;
            }
            if (rightPressed) {
                angle += 5;
            }

            double nextPlayerX = playerX + deltaX;
            double nextPlayerY = playerY + deltaY;

            if (nextPlayerX >= 50 && nextPlayerX <= WINDOW_WIDTH - 50 && nextPlayerY >= 50 && nextPlayerY <= WINDOW_HEIGHT - 50) {
                playerX = nextPlayerX;
                playerY = nextPlayerY;
            } else {
                crashed = true;
                showCrashMessage();
            }
        }
    }

    private void render() {
        gc.clearRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        drawRaceTrack();
        gc.save();
        gc.translate(playerX, playerY);
        gc.rotate(angle);
        gc.drawImage(carImage, -carImage.getWidth() / 2, -carImage.getHeight() / 2);
        gc.restore();
    }

    private void showCrashMessage() {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Crash Alert");
            alert.setHeaderText(null);
            alert.setContentText("You've crashed! Press OK to restart!");

            alert.showAndWait();
            crashed = false;
            playerX = WINDOW_WIDTH / 2;
            playerY = WINDOW_HEIGHT / 2;
            angle = 0;
        });
    }

    private void startBoostTimer() {
        boostTimer = new Timer();
        boostTimer.schedule(new TimerTask() {
            int secondsLeft = 3;

            @Override
            public void run() {
                Platform.runLater(() -> {
                    boostStatusLabel.setText("BOOST ACTIVATED!! " + secondsLeft + " remaining");
                });
                secondsLeft--;

                if (secondsLeft < 0) {
                    boostTimer.cancel();
                    isBoosted = false;
                    speed = 3.0;
                    startCooldownTimer();
                }
            }
        }, 0, 1000);
    }

    private void startCooldownTimer() {
        cooldownTimer = new Timer();
        cooldownTimer.schedule(new TimerTask() {
            int secondsLeft = 3;

            @Override
            public void run() {
                Platform.runLater(() -> {
                    boostStatusLabel.setText("Cooldown: " + secondsLeft + "s");
                });
                secondsLeft--;

                if (secondsLeft < 0) {
                    cooldownTimer.cancel();
                    canUseBoost = true;
                    Platform.runLater(() -> {
                        boostStatusLabel.setText("");
                    });
                }
            }
        }, 0, 1000);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
