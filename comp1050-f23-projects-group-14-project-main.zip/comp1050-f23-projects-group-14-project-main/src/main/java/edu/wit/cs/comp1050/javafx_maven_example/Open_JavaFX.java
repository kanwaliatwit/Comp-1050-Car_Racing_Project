package edu.wit.cs.comp1050.javafx_maven_example;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Open_JavaFX {
	
	/**
	 * @param args
	 */
	public static void main(final String[] args) {
		//App.main(args);
		RacingGame.main(args);
	}
	
}
