package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PAC extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        StackPane sp = new StackPane();
        Arc pacMan = createPacMan();

        HBox hBox = new HBox();
        hBox.setSpacing(10);
        hBox.setAlignment(Pos.CENTER);

        Button btnOpenCloseMouth = new Button("Open/Close Mouth");

        // Create a timeline to animate the mouth movement
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(0), e -> openMouth(pacMan)),
                new KeyFrame(Duration.seconds(0.1), e -> closeMouth(pacMan))
        );

        // Stop the timeline after completing one cycle
        timeline.setCycleCount(2);
        timeline.setOnFinished(event -> timeline.stop());

        btnOpenCloseMouth.setOnAction(e -> {
            timeline.playFromStart();
        });

        hBox.getChildren().addAll(btnOpenCloseMouth);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(sp);
        borderPane.setBottom(hBox);
        BorderPane.setAlignment(hBox, Pos.CENTER);

        Scene scene = new Scene(borderPane, 250, 200);

        sp.getChildren().add(pacMan);

        primaryStage.setTitle("Pac-Man");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Arc createPacMan() {
        Arc pacMan = new Arc(0, 0, 50, 50, 30, 300);
        pacMan.setStroke(Color.BLACK);
        pacMan.setFill(Color.YELLOW);
        pacMan.setType(ArcType.ROUND);
        return pacMan;
    }

    private void openMouth(Arc pacMan) {
        pacMan.setStartAngle(45);
        pacMan.setLength(270);
    }

    private void closeMouth(Arc pacMan) {
        pacMan.setStartAngle(30);
        pacMan.setLength(300);
    }
}
