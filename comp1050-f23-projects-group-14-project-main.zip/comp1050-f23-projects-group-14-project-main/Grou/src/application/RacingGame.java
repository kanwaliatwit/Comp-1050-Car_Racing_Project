package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class RacingGame extends Application {

    private static final int WINDOW_WIDTH = 1920;
    private static final int WINDOW_HEIGHT = 1080;
    private static final double PLAYER_SPEED = 5.0;

    private double playerX = WINDOW_WIDTH / 2;
    private double playerY = WINDOW_HEIGHT / 2;
    private boolean upPressed = false;
    private boolean downPressed = false;
    private boolean leftPressed = false;
    private boolean rightPressed = false;

    @Override
    public void start(Stage primaryStage) {
        Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();

        StackPane root = new StackPane(canvas);
        Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);

        scene.setOnKeyPressed(e -> {
            KeyCode keyCode = e.getCode();
            if (keyCode == KeyCode.UP) upPressed = true;
            if (keyCode == KeyCode.DOWN) downPressed = true;
            if (keyCode == KeyCode.LEFT) leftPressed = true;
            if (keyCode == KeyCode.RIGHT) rightPressed = true;
        });

        scene.setOnKeyReleased(e -> {
            KeyCode keyCode = e.getCode();
            if (keyCode == KeyCode.UP) upPressed = false;
            if (keyCode == KeyCode.DOWN) downPressed = false;
            if (keyCode == KeyCode.LEFT) leftPressed = false;
            if (keyCode == KeyCode.RIGHT) rightPressed = false;
        });

        primaryStage.setScene(scene);
        primaryStage.setTitle("RacingGame");
        primaryStage.show();

        new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
                render(gc);
            }
        }.start();
    }

    private void update() {
        if (upPressed) playerY -= PLAYER_SPEED;
        if (downPressed) playerY += PLAYER_SPEED;
        if (leftPressed) playerX -= PLAYER_SPEED;
        if (rightPressed) playerX += PLAYER_SPEED;
    }

    private void render(GraphicsContext gc) {
        gc.clearRect(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
        gc.setFill(Color.RED);
        gc.fillOval(playerX, playerY, 20, 40); // Player character (circle)
    }

    public static void main(String[] args) {
        launch(args);
    }
}
